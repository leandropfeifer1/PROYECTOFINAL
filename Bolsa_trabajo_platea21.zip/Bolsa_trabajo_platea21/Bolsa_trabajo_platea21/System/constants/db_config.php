<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bwirejobs_db";
?>